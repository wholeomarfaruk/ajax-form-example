<?php 

class HomeController
{

    public function index()
    {
        Controller::view('index');
    }



}